from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Search Tools',
    author='siliwen',
    author_email='siliwen@gmail.com',
    py_modules=['vsearch']
)